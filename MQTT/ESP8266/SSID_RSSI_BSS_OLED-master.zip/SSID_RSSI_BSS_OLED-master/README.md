# SSID_RSSI_BSS_OLED
A simple signal strength indicator for the ESP8266 and 128 x 32 OLED Display
This is a simple Arduino IDE sketch that displays the RSSI, BSSID and signal "bars" of a given SSID
