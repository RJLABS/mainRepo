
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'arm_class_marks_example' 
 * Target:  'ARMCM0' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


#endif /* RTE_COMPONENTS_H */
