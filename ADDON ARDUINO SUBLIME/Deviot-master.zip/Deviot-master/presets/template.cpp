//${src_file_name}

#include <avr/io.h>
#include <util/delay.h>

int main(void){
    // put your main code here:
}