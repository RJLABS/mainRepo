Before report an issue, please make sure it hasn't been reported before.

If you need information about an option or feature make sure to first look into the [Deviot Wiki](https://github.com/gepd/Deviot/wiki)

### Operating system

### Board used

### Description of problem

### Error(s) in ST Console? (View > Show Console)

### Steps to Reproduce

### Actual Results

### Expected Results

### Additional info

*You can edit the text above according to your need*