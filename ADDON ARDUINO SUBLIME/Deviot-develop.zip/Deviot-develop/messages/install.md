'########::'########:'##::::'##:'####::'#######::'########:
 ##.... ##: ##.....:: ##:::: ##:. ##::'##.... ##:... ##..::
 ##:::: ##: ##::::::: ##:::: ##:: ##:: ##:::: ##:::: ##::::
 ##:::: ##: ######::: ##:::: ##:: ##:: ##:::: ##:::: ##::::
 ##:::: ##: ##...::::. ##:: ##::: ##:: ##:::: ##:::: ##::::
 ##:::: ##: ##::::::::. ## ##:::: ##:: ##:::: ##:::: ##::::
 ########:: ########:::. ###::::'####:. #######::::: ##::::
........:::........:::::...:::::....:::.......::::::..:::::

Sublime Text plugin for IoT development

**IMPORTANT!**

- This plugin requires **Python 2** 

If after installing python2 you experience any problems, go to `Deviot Menu > Options > Remove Preferences File` and restart Sublime Text

If you keep having problems, please submit an issue explaining your problem [here](https://github.com/gepd/Deviot/issues/new)

--------------------------------

**¡IMPORTANTE!**
    
- Este plugin requiere **Python 2**

Si después de instalar python experimentas algún problema, anda a Menu `Deviot > Opciones > Eliminar Archivos de Prefencias` y reinicia Sublime Text.

Si continúas con problemas, por favor escríbenos sobre tu problema [aqui](https://github.com/gepd/Deviot/issues/new)